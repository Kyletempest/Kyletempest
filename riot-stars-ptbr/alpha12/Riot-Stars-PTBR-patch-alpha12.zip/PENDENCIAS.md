# O que falta para declarar o projeto completo

A alpha12 amplia e revisa os catálogos atuais de roteiro principal, diálogos fortes de batalha e textos estáticos dos executáveis. Isso não estabelece o total de textos do jogo nem substitui um teste completo.

- **Execução no DuckStation:** conferir do início ao final, com rotas alternativas, mortes de aliados e opções de conversa. Validar recortes, acentos, nomes e avanço dos combates.
- **Salvar e carregar:** testar saves normais, suspensão, formatação e mensagens de erro, além do teclado e das confirmações SIM/NÃO. O formato do save e os nomes dos arquivos foram preservados; falta validação prática.
- **Cinco transições de capítulo e final:** cartões gráficos traduzidos precisam de confirmação em execução. A imagem final foi traduzida; os 15 vídeos foram auditados, com textos localizados na abertura e nos dez créditos finais. Falta conferir sua reprodução completa no DuckStation. Nomes pessoais da equipe nos créditos mantêm a grafia original.
- **Texto fora dos catálogos:** a revisão adicional já encontrou 134 trechos que o extrator antigo não capturava. A investigação de outros formatos/fragmentos deve continuar; não há denominador global confiável.
- **ZDATA.BIN:** contém cópias japonesas e material antigo. Ainda não foi demonstrado que suas mensagens sejam carregadas no jogo. Não foi alterado nem contado como cobertura jogável.
- **Parágrafos legados de HEXMAP:** alguns textos suplementares traduzidos parecem rascunhos e têm alcance em execução não demonstrado. Não contam como cenas testadas.
- **Fonte de batalha experimental:** sua instalação preserva a alocação original, mas ocupa uma rotina sem referências estáticas detectadas. Chamadas indiretas calculadas não foram totalmente excluídas; testar especialmente IA, batalhas e transições.

Três listagens técnicas de assembly no roteiro foram preservadas. As tabelas japonesas de dakuten desativadas na tela de nome e uma amostra de fonte sem referência conhecida não são contabilizadas como diálogos pendentes. Os originais continuam preservados.
