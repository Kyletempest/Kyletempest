# Alpha12 HLE runtime verification

Built open-source libretro PCSX-ReARMed commit 7b0e8f8 and a small headless C frontend. Explicit pcsx_rearmed_bios=HLE; empty local system directory; no proprietary BIOS downloaded or used. Logs confirm Using HLE BIOS and manual executable boot. This is a real emulation run, not a DuckStation test.

Actual rendered evidence (all frame numbers are retro_run call counts, sampled every 120 calls):

- alpha12/frame-001560.png: Portuguese continue/load/new-game/title menu. Selecting continue without a card produces Portuguese missing-memory-card guidance (frame2160).
- alpha12-newgame/frame-002160.png: Digite seu nome and Latin/accent naming grid.
- alpha12-accent/frame-002880.png: selected É from grid and inserted visibly into player name.
- alpha12-story/frame-003600.png: chapter caption Em meio à tempestade.
- alpha12-story/frame-006240.png and frame-011040.png: Portuguese dialogue over first battle map; portraits and map render.
- alpha12-story/frame-014280.png: first battle, skill selection and Portuguese insufficient-Power-Stones message.
- alpha12-story/frame-015240.png: CAIN unit popup.
- alpha12-menu/frame-014400.png: map tooltip Mover unidade.
- alpha12-battle-menu/frame-014400.png: CAIN / ESPADACHIM unit status; Portuguese equipment/status labels rendered. ATTACK, DEFENSE, RESIST, LEVEL remain English in this screen, and compact equipment/skill text overlaps or truncates. These are observed limitations.

Sources harness-story.c and harness-accent.c preserve input schedules; harness.c is final status-screen schedule. A is libretro circle, B cross, X triangle. Start900; down1200,1300; circle pulses every180 from1440; Start3200 accepts entered name. Repeated circle advances first dialogue into battle around frame12960. Status schedule stops circle after12800, cancels at13400/13500/13600, triangle13800. Accent schedule instead moves down at2200/2300/2400/2500 and circle2700. Naming name repetition in story is automation-generated A characters.

Build/run cost: one shallow public GitHub repository clone plus its libpicofe submodule; local gcc/make build, no package installation. Nine short headless runs (including two RAM/register capture reruns), 108,600 emulated frames in total, disk footprint about180 MB including source/build/screenshots. No original disc files modified. Full game, battle completion, saves, DuckStation behavior and movie playback remain unverified.

RAM/register capture: alpha12-battle-menu/battle-ram.bin is 2 MiB system RAM after frame14500. retro_serialize was called first to synchronize Lightrec register state, then psxRegs was read using this exact core ELF offset (0x280400). GP=0x801153e0, SP=0x801fff88, RA=0x800d6bec. ASCII remaining labels in RAM: ATTACK0x801154a4, DEFENSE0x801154ac, RESIST0x801154b4. Source harness.c includes the capture logic.

## Status correction rerun

The rebuilt alpha12 base image was run again for 14,500 frames using the same harness and HLE BIOS. `alpha12-status-fixed/frame-014400.png` confirms ESP RUBRA, ARM COURO and DANCA fit, alongside ATAQUE, DEFESA, FOR, AGI, DES, CAR and SOR. No overlap in those three revised name fields. Other item/skill names and full playthrough remain unverified. The final image adds the independently verified movie sectors to this tested base.
