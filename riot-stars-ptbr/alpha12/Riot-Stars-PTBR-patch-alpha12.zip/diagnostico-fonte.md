# Actual battle small-font atlas: alpha10 label failure

The alpha07 converter repair stopped out-of-bounds SJIS-table reads, but its
lowercase mapping was wrong for the texture descriptors actually drawn. The
old CPU test checked converter output against the same mapping assumption; it
did not establish which pixels those IDs select. Original Japanese fullwidth
lowercase conversion is not evidence that the resulting IDs draw Latin letters.

For `Sykes`, alpha10 emits `[83,57,43,37,51]`. Following those IDs through the
actual descriptor table and original texture draws **S9+%3**. Uppercase
`[83,89,75,69,83]` selects **SYKES**. The lowercase pixels themselves exist,
but none of the 512 installed descriptors addresses their UV positions.
Outputting raw ASCII lowercase IDs is also incorrect: e.g. descriptor 97
selects UV (8,40), in the Japanese region, rather than lowercase a at (8,16).

## Code and asset trace

All offsets below are in the original `extracted/KOUSEI.EXE`; RAM equals file
offset plus 0x8000F800.

1. The existing source-word converter is file 0x21EF4 / RAM 0x800316F4. Original
   fullwidth `a` maps through the SJIS table to 0x6100; file 0x22034–0x22044
   subtracts 64 from that high byte. That produces ID 33, not a supported
   lowercase-letter descriptor. The alpha07 pair repair reproduced that rule.
2. Names are stored in the converted buffer beginning RAM 0x801647D4. File
   0x10110 and 0x561D8 call RAM 0x80030218 with these converted names. File
   0x20B0C loads each ID and 0x20B68–0x20B6C writes it into the tilemap at
   RAM 0x801650FC, plus a color-bank offset. IDs 0xDE/0xDF are combining marks.
3. File 0x1DA98 onward creates an 8x8 tile configuration. File 0x1DAC4 sets
   its descriptor pointer to RAM 0x80157428; 0x1DAD0 sets its map pointer to
   RAM 0x801650FC. Its background object is drawn by RAM 0x800C19EC
   (file 0xB21EC), called at e.g. file 0x1AC64.
4. The background draw routine directly indexes descriptors: file 0xB25A8
   reads configuration+12 (map); 0xB25B4 reads the 16-bit tile ID; 0xB25C0
   multiplies it by eight; 0xB25C4 reads configuration+8 (descriptor base);
   0xB25D4 adds the ID offset; 0xB25F4 loads the descriptor U coordinate.
   There is no later ASCII remapping.
5. File 0x880C–0x8824 builds 512 descriptors from RAM 0x800E579C (file
   0xD5F9C) into RAM 0x80157428 using RAM 0x800156CC (file 0x5ECC).
   Source entries have U/V at bytes 0/1 and CLUT at +2. Constructor copies
   U/V and overwrites descriptor+6 with the supplied texture-page value 15.
   That page is VRAM x960,y0. The source CLUT 0x7B40 is relocated to x304.
6. Startup file 0x87F4 calls RAM 0x80063E64. Its first asset read at 0x54744
   uses type 0x22 and sector offset zero; the upload rectangle table at file
   0xE73F8 gives image x960,y0 and CLUT x304,y480. These match the first TIM
   in original `TACTICS/INICHR.BIN`: 4bpp, CLUT header x304,y480,w16,h16;
   image header at 0x214, image x960,y0,w64 VRAM words,h256. Pixel bytes start
   at 0x220. Four pixels per VRAM word give a 256x256 atlas.

## Independent pixel verification

Run `python analysis/battle/verify_small_atlas.py`. It reads original assets
only and writes evidence under `analysis/battle/`. It does not import the
pair-font converter or its mapping helper and does not modify builds.

The script verifies all 26 uppercase descriptor UVs; compares twelve manually
reviewed capital silhouettes needed by SYKES, PIARIS and BANDIDO against fixed
8x8 bitmap oracles; checks that all 512 descriptors miss lowercase-row UVs;
and reconstructs the erroneous alpha10 name from actual texture texels.

- `small_atlas_name_proof.png`: erroneous alpha10 Sykes, uppercase names and
  actual lowercase texture pixels, enlarged with nearest-neighbor scaling.
- `small_atlas_original.png`: full original atlas in palette-index grayscale.
- `small_atlas_validation.json`: original asset hashes, checks and all 512 UVs.

The minimal compatible label correction is to output the verified uppercase
IDs for Latin letters, transliterating accented letters before capitalizing.
Adding addressable lowercase descriptors would require a broader descriptor
allocation change. These checks establish texture pixels and the code path,
but are not an emulator run or a proof of every runtime window's state.
